# 25e39067-2da0-4f96-9cb1-4c9ad792adc2-8e832f98-0f06-44c0-bba9-a4009b2e77c8
https://sonar.server.examly.io/dashboard?id=iamneo-production_25e39067-2da0-4f96-9cb1-4c9ad792adc2-8e832f98-0f06-44c0-bba9-a4009b2e77c8&amp;codeScope=overall
