"""Health Advice LLM Agent"""

# TODO: Implement HealthAdviceLLMAgent to generate risk-appropriate personalized clinical guidance
# PURPOSE: Use LLM to create actionable health advice tailored to risk level (urgent for high-risk, reassuring for low-risk)
# PARAMETERS: Extracted fields dictionary, risk score float (0.0-1.0), severity level string, boolean is_high_risk flag, optional diagnoses list
# RETURNS: String containing personalized clinical guidance text (emergency instructions for high-risk, self-care for low-risk)
