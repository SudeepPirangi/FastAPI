"""Node : Low Risk Advice - Generate reassuring health advice (low-risk path)"""

# TODO: Implement low_risk_advice_node to invoke LLM-based reassuring guidance for low-risk patients
# PURPOSE: Generate reassuring guidance with self-care recommendations, OTC options, warning signs for low-risk pathway only
# PARAMETERS: Workflow state with extracted_data, risk_score, severity_level, is_high_risk=False
# RETURNS: State with health_advice text plus explicitly marked differential_diagnoses and treatment_plan with status="low_risk_path" to distinguish intentional skip from error
